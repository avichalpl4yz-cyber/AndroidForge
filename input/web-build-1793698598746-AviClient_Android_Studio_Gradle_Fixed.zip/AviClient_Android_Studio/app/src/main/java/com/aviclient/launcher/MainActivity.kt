package com.aviclient.launcher

import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF090711)
private val Panel = Color(0xFF171326)
private val Purple = Color(0xFF9B6DFF)
private val Muted = Color(0xFFB8AECF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Purple,
                    secondary = Color(0xFFC4A7FF),
                    background = Bg,
                    surface = Panel
                )
            ) {
                AviClientApp(
                    onLaunchMinecraft = {
                        val launch = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
                        if (launch != null) {
                            try { startActivity(launch) }
                            catch (_: ActivityNotFoundException) {
                                Toast.makeText(this, "Minecraft could not be opened.", Toast.LENGTH_LONG).show()
                            }
                        } else {
                            Toast.makeText(this, "Official Minecraft was not found. Install it first.", Toast.LENGTH_LONG).show()
                        }
                    }
                )
            }
        }
    }
}

private data class Module(val name: String, val category: String, val detail: String, val icon: ImageVector, val purple: Boolean = false)

private val modules = listOf(
    Module("FPS Counter", "Performance", "Display current frame rate", Icons.Default.Speed, true),
    Module("Performance HUD", "Performance", "Show performance statistics", Icons.Default.MonitorHeart, true),
    Module("Low Particles", "Performance", "Reduce visual particle load", Icons.Default.Grain, true),
    Module("CPS Counter", "PvP & HUD", "Display clicks per second", Icons.Default.TouchApp),
    Module("Keystrokes HUD", "PvP & HUD", "Show input indicators", Icons.Default.Keyboard),
    Module("Coordinates", "World & Navigation", "Display player coordinates", Icons.Default.Explore),
    Module("Waypoints", "World & Navigation", "Save named coordinate markers", Icons.Default.Place),
    Module("360° Free Look", "Camera", "Independent camera-look concept", Icons.Default.ThreeSixty),
    Module("Perspective Free Look", "Camera", "Look around without steering", Icons.Default.ViewInAr),
    Module("Structure Studio", "Structures", "Structure library and preview workspace", Icons.Default.Architecture),
    Module("Hologram Preview", "Structures", "Ghost-structure preview integration placeholder", Icons.Default.Layers),
    Module("Build Assist", "Structures", "Block placement guide integration placeholder", Icons.Default.Construction),
    Module("Cosmetics Gallery", "Cosmetics", "Browse cosmetic concepts and packs", Icons.Default.AutoAwesome),
    Module("Cape Preview", "Cosmetics", "Preview compatible cape assets", Icons.Default.Checkroom)
)

@Composable
private fun AviClientApp(onLaunchMinecraft: () -> Unit) {
    var tab by remember { mutableStateOf("Home") }
    var search by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("All") }
    val tabs = listOf("Home", "Modules", "Cosmetics", "Structures", "Settings")
    Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
        Column {
            Row(
                Modifier.fillMaxWidth().background(
                    Brush.horizontalGradient(listOf(Color(0xFF241344), Bg))
                ).padding(horizontal = 20.dp, vertical = 18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("AVI", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black)
                    Text("CLIENT  •  BEDROCK EDITION", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                }
                Surface(color = Purple.copy(alpha = .18f), shape = RoundedCornerShape(20.dp)) {
                    Text("HOTFIX 1.26.52.3", color = Color(0xFFD9C8FF), modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                tabs.forEach { item ->
                    val selected = tab == item
                    Text(
                        item,
                        color = if (selected) Color.White else Muted,
                        fontSize = 11.sp,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.weight(1f).clickable { tab = item }.background(if (selected) Purple.copy(alpha = .22f) else Color.Transparent, RoundedCornerShape(10.dp)).padding(vertical = 12.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
            when (tab) {
                "Home" -> HomeScreen(onLaunchMinecraft)
                "Modules" -> ModulesScreen(search, { search = it }, category, { category = it })
                "Cosmetics" -> InfoScreen("Cosmetics Gallery", "A place for compatible, user-imported cosmetic packs and previews.", listOf("Cape and skin-pack discovery", "Wings and halo asset previews", "Local cosmetic pack organization", "Online visibility depends on server/client support"))
                "Structures" -> InfoScreen("Structure Studio", "Workspace specification for importing supported structure files.", listOf(".mcstructure import pathway", ".mcpack structure-pack inspection", "Ghost preview mode", "Build-assist placement guide", "Rotate, mirror and align controls", "Large-structure performance options"))
                else -> InfoScreen("Settings", "AviClient launcher settings.", listOf("Dark purple appearance", "Minecraft Bedrock target: 1.26.52.3", "Android target SDK: 33", "Client integration status: not connected"))
            }
        }
    }
}

@Composable
private fun HomeScreen(onLaunch: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF44227B), Color(0xFF19112B))), RoundedCornerShape(22.dp)).padding(20.dp)) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("YOUR WORLD.
YOUR RULES.", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black, lineHeight = 31.sp)
                    Text("A Bedrock companion launcher", color = Color(0xFFD6C8F4), fontSize = 13.sp)
                    Button(onClick = onLaunch, colors = ButtonDefaults.buttonColors(containerColor = Purple), modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("LAUNCH MINECRAFT")
                    }
                }
            }
        }
        item { Text("QUICK ACCESS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Modules", "270+ planned", Modifier.weight(1f), Icons.Default.Extension)
                StatCard("Cosmetics", "3,000+ target", Modifier.weight(1f), Icons.Default.AutoAwesome)
            }
        }
        item {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(16.dp)) {
                Text("STRUCTURE STUDIO", color = Color.White, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("Import supported structures and prepare hologram previews.", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                Text("PREVIEW  •  BUILD ASSIST  •  .MCSTRUCTURE  •  .MCPACK", color = Color(0xFFC5A8FF), fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }
        item {
            Text("INTEGRATION NOTE", color = Muted, fontSize = 10.sp)
            Text("This starter app opens the installed official Minecraft app. In-game overlays, arbitrary native mod injection, public-server cosmetic visibility and live hologram rendering need separate compatible Bedrock integrations; they are not active in this starter build.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, modifier: Modifier, icon: ImageVector) {
    Column(modifier.background(Panel, RoundedCornerShape(16.dp)).padding(14.dp)) {
        Icon(icon, contentDescription = null, tint = Purple)
        Spacer(Modifier.height(8.dp))
        Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text(title, color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun ModulesScreen(search: String, onSearch: (String) -> Unit, category: String, onCategory: (String) -> Unit) {
    val categories = listOf("All", "Performance", "PvP & HUD", "World & Navigation", "Camera", "Structures", "Cosmetics")
    val visible = modules.filter { (category == "All" || it.category == category) && it.name.contains(search, true) }
    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
        OutlinedTextField(value = search, onValueChange = onSearch, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Search modules…") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(categories) { c ->
                FilterChip(selected = category == c, onClick = { onCategory(c) }, label = { Text(c, fontSize = 10.sp) })
            }
        }
        LazyColumn(contentPadding = PaddingValues(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(visible) { module ->
                Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(module.icon, contentDescription = null, tint = if (module.purple) Purple else Muted)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(module.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Text(module.detail, color = Muted, fontSize = 10.sp)
                    }
                    Text("INFO", color = Purple, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun InfoScreen(title: String, subtitle: String, points: List<String>) {
    LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text(title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold) }
        item { Text(subtitle, color = Muted, fontSize = 13.sp) }
        items(points) { point ->
            Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CheckCircleOutline, contentDescription = null, tint = Purple)
                Spacer(Modifier.width(10.dp))
                Text(point, color = Color.White, fontSize = 12.sp)
            }
        }
    }
}
