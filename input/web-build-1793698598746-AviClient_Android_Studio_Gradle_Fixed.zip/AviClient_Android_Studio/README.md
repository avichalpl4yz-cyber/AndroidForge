# AviClient Android Studio starter

A dark-purple Android launcher foundation for Minecraft Bedrock.

## Current starter features
- AviClient branded Compose UI
- Home, Modules, Cosmetics, Structures and Settings sections
- Searchable sample module catalog
- Launches the installed official Minecraft app (`com.mojang.minecraftpe`) when present
- Minecraft target compatibility label set to `1.26.52.3`
- Android `targetSdk = 33` (Android 13 target)

## Build toolchain
- Android Gradle Plugin: 8.9.2
- Gradle wrapper distribution: 8.11.1
- JDK: 17

## Build an APK
1. Install Android Studio and a compatible JDK 17.
2. Open this folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location.

## Important scope and limitations
This is a launcher starter project, not a completed in-game client or injector.
The sample module entries are UI/catalog entries; they do not modify Minecraft.
A launcher app cannot universally inject arbitrary `.so`, Java, or other mods into Bedrock.
Live FPS/CPS overlays, free-look camera control, waypoints, structure hologram rendering,
and cosmetics visible to other players require compatible in-game integration and testing.
`.mcstructure` and `.mcpack` import workflows are specified in the UI but are not yet implemented.
The `1.26.52.3` value is a requested compatibility target, not a verified Minecraft release/API compatibility claim.

## Package
`com.aviclient.launcher`
