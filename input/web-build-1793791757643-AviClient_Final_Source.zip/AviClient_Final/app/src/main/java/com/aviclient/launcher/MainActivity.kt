package com.aviclient.launcher

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val bg = Color(0xFF090711)
private val panel = Color(0xFF171326)
private val purple = Color(0xFFB56CFF)
private val muted = Color(0xFFB9B1C9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = purple, background = bg, surface = panel,
                onPrimary = Color.White, onBackground = Color.White, onSurface = Color.White
            )) {
                AviApp {
                    val intent = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
                    if (intent != null) startActivity(intent)
                    else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.mojang.minecraftpe")))
                }
            }
        }
    }
}

private data class Module(val name: String, val group: String, val detail: String)
private val moduleList = listOf(
    Module("FPS Counter", "HUD", "Performance readout placeholder"),
    Module("Coordinates", "HUD", "Coordinate overlay placeholder"),
    Module("CPS Counter", "HUD", "Clicks-per-second display placeholder"),
    Module("Keystrokes", "HUD", "Input display placeholder"),
    Module("Combo Display", "HUD", "Combat statistics display placeholder"),
    Module("Custom Crosshair", "PvP", "Crosshair resource integration placeholder"),
    Module("Small Totem", "PvP", "Totem texture option placeholder"),
    Module("Zoom", "Camera", "Zoom control placeholder"),
    Module("Free Look", "Camera", "Requires game-side camera integration"),
    Module("Perspective", "Camera", "Perspective control placeholder"),
    Module("Low Fire", "Visuals", "Low-fire resource option"),
    Module("Clear Water", "Visuals", "Water texture option"),
    Module("Custom Sky", "Visuals", "Sky resource option"),
    Module("Low Particles", "Performance", "Reduced visual effects option"),
    Module("Waypoints", "World", "Saved waypoint interface placeholder"),
    Module("Structure Preview", "Structures", "Structure integration placeholder"),
    Module("Cape Preview", "Cosmetics", "Local preview placeholder"),
    Module("Wing Preview", "Cosmetics", "Local preview placeholder"),
    Module("Pack Manager", "Utility", "Resource pack organization placeholder"),
    Module("Profile Manager", "Utility", "Launcher profile placeholder")
)

@Composable
private fun AviApp(onLaunch: () -> Unit) {
    val tabs = listOf("Home", "Modules", "PvP", "Cosmetics", "Visuals", "World", "Camera", "Structures", "Mods", "Settings")
    var tab by remember { mutableStateOf("Home") }
    var search by remember { mutableStateOf("") }
    var enabled by remember { mutableStateOf(setOf("FPS Counter", "Coordinates", "Low Particles")) }
    var compact by remember { mutableStateOf(false) }
    var animations by remember { mutableStateOf(true) }

    Column(Modifier.fillMaxSize().background(bg).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("AVI", color = purple, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                Text("CLIENT", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                Text("BEDROCK COMPANION", color = muted, fontSize = 9.sp, letterSpacing = 2.sp)
            }
            Surface(color = panel, shape = RoundedCornerShape(12.dp)) {
                Text("1.26.52.3 TARGET", color = purple, modifier = Modifier.padding(11.dp), fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            tabs.forEach { name ->
                FilterChip(selected = tab == name, onClick = { tab = name; search = "" }, label = { Text(name, fontSize = 11.sp) })
            }
        }
        when (tab) {
            "Home" -> Home(onLaunch)
            "Settings" -> Settings(compact, { compact = it }, animations, { animations = it })
            else -> {
                val group = when (tab) {
                    "PvP" -> "PvP"
                    "Cosmetics" -> "Cosmetics"
                    "Visuals" -> "Visuals"
                    "World" -> "World"
                    "Camera" -> "Camera"
                    "Structures" -> "Structures"
                    else -> null
                }
                ModulePage(tab, moduleList.filter { group == null || it.group == group }, search, { search = it }, enabled) {
                    enabled = if (it in enabled) enabled - it else enabled + it
                }
            }
        }
    }
}

@Composable
private fun Home(onLaunch: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Surface(color = panel, shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("YOUR GAME. YOUR STYLE.", color = purple, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("Welcome to AviClient", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                    Text("A customizable companion for Minecraft Bedrock.", color = muted, fontSize = 13.sp)
                    Button(onClick = onLaunch, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = purple)) {
                        Icon(Icons.Default.SportsEsports, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("LAUNCH MINECRAFT")
                    }
                }
            }
        }
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("20" to "MODULES", "10" to "SECTIONS", "1.0" to "VERSION").forEach { (v, label) ->
                Surface(Modifier.weight(1f), color = panel, shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(v, color = purple, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text(label, color = muted, fontSize = 9.sp)
                    }
                }
            }
        } }
        item { InfoCard("Quick start", "Browse modules by category. Switches in this prototype are interface states only.") }
        item { InfoCard("Compatibility target", "Bedrock 1.26.52.3 • Android ARM64. This is a target profile, not verified compatibility.") }
        item { InfoCard("Feature status", "This is a launcher UI prototype. It does not inject into Minecraft or activate native in-game modules.") }
    }
}

@Composable
private fun InfoCard(title: String, detail: String) {
    Surface(color = panel, shape = RoundedCornerShape(15.dp)) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold)
            Text(detail, color = muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ModulePage(title: String, modules: List<Module>, search: String, onSearch: (String) -> Unit, enabled: Set<String>, onToggle: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 15.dp)) {
        Text(title.uppercase(), color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp, bottom = 10.dp))
        Surface(color = panel, shape = RoundedCornerShape(13.dp)) {
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Search, contentDescription = null, tint = muted)
                Spacer(Modifier.width(8.dp))
                BasicTextField(value = search, onValueChange = onSearch, singleLine = true, textStyle = TextStyle(color = Color.White, fontSize = 14.sp), decorationBox = { inner ->
                    if (search.isEmpty()) Text("Search modules...", color = muted, fontSize = 14.sp)
                    inner()
                })
            }
        }
        val filtered = modules.filter { it.name.contains(search, true) || it.detail.contains(search, true) }
        LazyColumn(contentPadding = PaddingValues(vertical = 11.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered) { module ->
                Surface(color = panel, shape = RoundedCornerShape(14.dp)) {
                    Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(module.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text(module.detail, color = muted, fontSize = 11.sp)
                            Text(module.group.uppercase(), color = purple, fontSize = 9.sp, letterSpacing = 1.sp)
                        }
                        Switch(checked = module.name in enabled, onCheckedChange = { onToggle(module.name) })
                    }
                }
            }
            if (filtered.isEmpty()) item { Text("No matching modules.", color = muted) }
        }
    }
}

@Composable
private fun Settings(compact: Boolean, onCompact: (Boolean) -> Unit, animations: Boolean, onAnimations: (Boolean) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("SETTINGS", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        item { SettingRow("Compact interface", compact, onCompact) }
        item { SettingRow("UI animations", animations, onAnimations) }
        item { InfoCard("About AviClient", "Version 1.0.0 • Android launcher prototype • Opens the official installed Minecraft app.") }
    }
}

@Composable
private fun SettingRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Surface(color = panel, shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Color.White, modifier = Modifier.weight(1f))
            Switch(checked = value, onCheckedChange = onChange)
        }
    }
}
