# AviClient build notes

Toolchain pinned in this project:
- JDK 17
- Gradle wrapper 8.9
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- Android compile SDK 35

Open the extracted project in Android Studio on a computer, sync Gradle, then choose
Build > Build APK(s). Expected debug APK: app/build/outputs/apk/debug/app-debug.apk.

This source has not been compiled in this environment; therefore no error-free build
can be guaranteed. A cloud builder that overrides the Gradle wrapper may still fail.

The current app is a launcher UI prototype. Module toggles are placeholders and do
not implement game injection, native hooks, or in-game feature behavior.
