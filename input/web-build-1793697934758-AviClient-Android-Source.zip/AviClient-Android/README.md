# AviClient Android — Development Scaffold

AviClient is an Android companion launcher for the **official Minecraft Bedrock app**.
This repository is the first UI/launcher scaffold, not a finished Minecraft client or APK.

## Current starter features
- Black/red Compose launcher UI with purple performance accents.
- Detects the official Android package `com.mojang.minecraftpe`.
- Launches the installed official Minecraft app through Android's package launch intent.
- Early navigation tabs for Home, Modules and Cosmetics.
- Clearly labelled planned modules and cosmetic categories.

## Important limits
- The app does **not** inject code into Minecraft, patch the APK, bypass server rules, or modify protected game files.
- A normal Android launcher cannot independently add HUD overlays inside another app or make custom capes/wings visible to arbitrary public servers.
- Public-server cosmetic visibility requires the server to opt into and implement a compatible protocol/plugin, plus compatible client rendering. Other clients that do not implement that protocol will not display the cosmetics.
- Minecraft 1.26.52.3 is a requested target only. Version compatibility must be tested against the actual installed game build and supported Android APIs.
- The 325+ module and 300+ cosmetic counts are product goals, not implemented features in this scaffold.

## Build
Open this folder in a recent Android Studio version with JDK 17 and Android SDK Platform 35 installed. Allow Gradle sync, then build the `app` debug variant.

If Gradle reports a plugin/dependency version issue, update the Android Gradle Plugin, Kotlin plugin and Compose BOM together using versions supported by your installed Android Studio.

## Next milestones
1. Verify launch behavior on the target Samsung tablet and official Minecraft installation.
2. Add a version/device compatibility screen and diagnostics.
3. Define the Avi-compatible server cosmetic protocol and a reference server plugin.
4. Build a local cosmetic preview/editor using original or properly licensed assets.
5. Implement safe, permitted companion features; do not claim in-game HUD or FPS changes until an actual supported integration exists.
6. Add and test modules in small batches, with a compatibility matrix per Bedrock version.

## Branding
AviClient name; black background; red standard module accents; purple performance/FPS accents.
