package com.aviclient.launcher

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val AviBlack = Color(0xFF101014)
private val AviPanel = Color(0xFF202027)
private val AviRed = Color(0xFFE32636)
private val AviPurple = Color(0xFFA855F7)
private val AviText = Color(0xFFF4F1F5)
private val AviMuted = Color(0xFFAAA4AE)

data class ModuleItem(val name: String, val category: String, val accent: Color)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = AviBlack,
                    surface = AviPanel,
                    primary = AviRed,
                    secondary = AviPurple,
                    onBackground = AviText,
                    onSurface = AviText
                )
            ) {
                AviHome(
                    onLaunchMinecraft = { launchOfficialMinecraft() },
                    minecraftInstalled = isMinecraftInstalled()
                )
            }
        }
    }

    private fun isMinecraftInstalled(): Boolean =
        try {
            packageManager.getPackageInfo("com.mojang.minecraftpe", 0)
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }

    private fun launchOfficialMinecraft() {
        val intent = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        }
    }
}

@Composable
private fun AviHome(
    onLaunchMinecraft: () -> Unit,
    minecraftInstalled: Boolean
) {
    val modules = listOf(
        ModuleItem("Armor HUD", "HUD", AviRed),
        ModuleItem("Coordinates HUD", "HUD", AviRed),
        ModuleItem("FPS Counter", "Performance", AviPurple),
        ModuleItem("Performance Profile", "Performance", AviPurple),
        ModuleItem("Crosshair Editor", "Crosshair", AviRed),
        ModuleItem("Waypoint Manager", "Navigation", AviRed),
        ModuleItem("Cosmetic Preview", "Cosmetics", AviRed),
        ModuleItem("Keystrokes", "HUD", AviRed)
    )
    var selectedTab by remember { mutableStateOf("Home") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AviBlack)
            .padding(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(AviRed, RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("A", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("AVI CLIENT", color = AviText, fontSize = 23.sp, fontWeight = FontWeight.Black)
                Text("BEDROCK LAUNCHER • EARLY BUILD", color = AviMuted, fontSize = 10.sp)
            }
        }

        Spacer(Modifier.height(22.dp))
        Text("Welcome to AviClient", color = AviText, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(
            "Your Minecraft companion. Modules and cosmetics are being built in stages.",
            color = AviMuted,
            fontSize = 13.sp
        )
        Spacer(Modifier.height(16.dp))

        Button(
            onClick = onLaunchMinecraft,
            enabled = minecraftInstalled,
            colors = ButtonDefaults.buttonColors(containerColor = AviRed),
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(14.dp)
        ) {
            Text(
                if (minecraftInstalled) "LAUNCH OFFICIAL MINECRAFT" else "MINECRAFT NOT DETECTED",
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        }
        if (!minecraftInstalled) {
            Text(
                "Install the official Minecraft app to use this launch shortcut.",
                color = AviMuted,
                fontSize = 11.sp,
                modifier = Modifier.padding(top = 6.dp)
            )
        }

        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Home", "Modules", "Cosmetics").forEach { tab ->
                FilterChip(
                    selected = selectedTab == tab,
                    onClick = { selectedTab = tab },
                    label = { Text(tab) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = AviRed,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }
        Spacer(Modifier.height(12.dp))

        when (selectedTab) {
            "Home" -> {
                StatCard("325+", "Planned modules")
                Spacer(Modifier.height(8.dp))
                StatCard("300+", "Planned cosmetic designs")
                Spacer(Modifier.height(8.dp))
                StatCard("1.26.52.3", "Initial Bedrock compatibility target")
                Spacer(Modifier.height(12.dp))
                Text(
                    "Compatibility is not verified yet. This starter app does not inject into Minecraft or alter game files.",
                    color = AviMuted,
                    fontSize = 12.sp
                )
            }
            "Modules" -> {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(modules) { item ->
                        Row(
                            modifier = Modifier.fillMaxWidth()
                                .background(AviPanel, RoundedCornerShape(12.dp))
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(9.dp).background(item.accent, RoundedCornerShape(50)))
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(item.name, color = AviText, fontWeight = FontWeight.SemiBold)
                                Text(item.category, color = AviMuted, fontSize = 11.sp)
                            }
                            Spacer(Modifier.weight(1f))
                            Text("PLANNED", color = AviMuted, fontSize = 9.sp)
                        }
                    }
                }
            }
            "Cosmetics" -> {
                Text("AviCosmetics", color = AviRed, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Halo, wings, capes, auras and accessories will be previewable here. Other players can see them only on servers that implement the Avi cosmetic protocol or another explicitly compatible system.",
                    color = AviMuted,
                    fontSize = 13.sp
                )
                Spacer(Modifier.height(12.dp))
                listOf("Halos", "Wings", "Capes", "Auras & trails", "Hats & accessories").forEach {
                    StatCard(it, "Cosmetic collection — planned")
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "AVI CLIENT • BUILD 0.1.0 • DEVELOPMENT SCAFFOLD",
            color = AviMuted,
            fontSize = 9.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}

@Composable
private fun StatCard(title: String, subtitle: String) {
    Row(
        modifier = Modifier.fillMaxWidth()
            .background(AviPanel, RoundedCornerShape(12.dp))
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(title, color = AviText, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text(subtitle, color = AviMuted, fontSize = 11.sp)
        }
    }
}
